<template>
  <div>
    <Welcome />
    <DoctorBottomNav />
  </div>
</template>

<script setup lang="ts">
import DoctorBottomNav from '~/components/DoctorBottomNav.vue'
</script>