<template>
  <Welcome />
</template>