
// @ts-nocheck
import locale_en_46json_5fa0eace from "#nuxt-i18n/5fa0eace";
import locale_ar_46json_2275bfa6 from "#nuxt-i18n/2275bfa6";

export const localeCodes =  [
  "en",
  "ar"
]

export const localeLoaders = {
  en: [
    {
      key: "locale_en_46json_5fa0eace",
      load: () => Promise.resolve(locale_en_46json_5fa0eace),
      cache: true
    }
  ],
  ar: [
    {
      key: "locale_ar_46json_2275bfa6",
      load: () => Promise.resolve(locale_ar_46json_2275bfa6),
      cache: true
    }
  ]
}

export const vueI18nConfigs = []

export const nuxtI18nOptions = {
  restructureDir: "i18n",
  experimental: {
    localeDetector: "",
    switchLocalePathLinkSSR: false,
    autoImportTranslationFunctions: false,
    typedPages: true,
    typedOptionsAndMessages: false,
    generatedLocaleFilePathFormat: "absolute",
    alternateLinkCanonicalQueries: false,
    hmr: true
  },
  bundle: {
    compositionOnly: true,
    runtimeOnly: false,
    fullInstall: true,
    dropMessageCompiler: false,
    optimizeTranslationDirective: true
  },
  compilation: {
    strictMessage: true,
    escapeHtml: false
  },
  customBlocks: {
    defaultSFCLang: "json",
    globalSFCScope: false
  },
  locales: [
    {
      code: "en",
      name: "English",
      iso: "en-US",
      dir: "ltr",
      files: [
        {
          path: "D:/wamp64/www/doctor-booking-frontend/i18n/locales/en.json",
          cache: undefined
        }
      ]
    },
    {
      code: "ar",
      name: "العربية",
      iso: "ar-EG",
      dir: "rtl",
      files: [
        {
          path: "D:/wamp64/www/doctor-booking-frontend/i18n/locales/ar.json",
          cache: undefined
        }
      ]
    }
  ],
  defaultLocale: "en",
  defaultDirection: "ltr",
  routesNameSeparator: "___",
  trailingSlash: false,
  defaultLocaleRouteNameSuffix: "default",
  strategy: "prefix",
  lazy: false,
  langDir: "locales/",
  rootRedirect: undefined,
  detectBrowserLanguage: {
    alwaysRedirect: false,
    cookieCrossOrigin: false,
    cookieDomain: null,
    cookieKey: "i18n_redirected",
    cookieSecure: false,
    fallbackLocale: "en",
    redirectOn: "root",
    useCookie: true
  },
  differentDomains: false,
  baseUrl: "",
  customRoutes: "page",
  pages: {},
  skipSettingLocaleOnNavigate: false,
  types: "composition",
  debug: false,
  parallelPlugin: false,
  multiDomainLocales: false,
  i18nModules: []
}

export const normalizedLocales = [
  {
    code: "en",
    name: "English",
    iso: "en-US",
    dir: "ltr",
    files: [
      {
        path: "D:/wamp64/www/doctor-booking-frontend/i18n/locales/en.json",
        cache: undefined
      }
    ]
  },
  {
    code: "ar",
    name: "العربية",
    iso: "ar-EG",
    dir: "rtl",
    files: [
      {
        path: "D:/wamp64/www/doctor-booking-frontend/i18n/locales/ar.json",
        cache: undefined
      }
    ]
  }
]

export const NUXT_I18N_MODULE_ID = "@nuxtjs/i18n"
export const parallelPlugin = false
export const isSSG = false
export const hasPages = true

export const DEFAULT_COOKIE_KEY = "i18n_redirected"
export const DEFAULT_DYNAMIC_PARAMS_KEY = "nuxtI18nInternal"
export const SWITCH_LOCALE_PATH_LINK_IDENTIFIER = "nuxt-i18n-slp"
/** client **/

/** client-end **/